<?php
/*
Plugin Name: Nord Share and Follow Buttons
Plugin URI: https://themeforest.net/user/nordstudio/portfolio
Description: A simple plugin that enables you to add share and follow buttons.
Version: 1.0
Text Domain: nord-share-and-follow-buttons
Author: Nord Studio
Author URI: https://themeforest.net/user/nordstudio
License: GPL2
*/

/**
 * Enqueue public plugin styles.
 *
 * @since Nord Share and Follow Buttons 1.0
 */ 
function nsafb_enqueue_scripts() {
  wp_register_style( 'nord-share-and-follow-buttons', plugin_dir_url( __FILE__ ) . 'assets/css/nord-share-and-follow-buttons.min.css', array(), '1.0' );
  wp_register_script( 'nord-share-and-follow-buttons', plugin_dir_url( __FILE__ ) . 'assets/js/public/nord-share-and-follow-buttons.min.js', array( 'jquery' ), '1.0', true );
}
add_action( 'wp_enqueue_scripts', 'nsafb_enqueue_scripts' );

/**
 * Load textdomain.
 *
 * @since Nord Share and Follow Buttons 1.0
 */ 
function nsafb_load_plugin_textdomain() {
  load_plugin_textdomain( 'nsafb', false, dirname( plugin_basename( __FILE__ ) ) . '/languages/' );
}
add_action( 'plugins_loaded', 'nsafb_load_plugin_textdomain', 10 );

/**
 * Get HTML with post share buttons.
 *
 * @since Nord Share and Follow Buttons 1.0
 */
function nsafb_get_share_buttons( $display_icon = true, $display_name = true ) {
  $post = get_post();

  if( ! $post )
    return;

  wp_enqueue_style( 'nord-share-and-follow-buttons' );
  wp_enqueue_script( 'nord-share-and-follow-buttons' );

  $thumbnail_src = '';
  $thumbnail = wp_get_attachment_image_src( get_post_thumbnail_id( $post->ID ), 'post-thumbnail' );
  
  if( $thumbnail )
    $thumbnail_src = urlencode( esc_url( $thumbnail['0'] ) );

  $post_permalink = urlencode( esc_url( get_permalink( $post->ID ) ) );
  $title          = urlencode( strip_tags( get_the_title() ) );
  $excerpt        = urlencode( strip_tags( get_the_excerpt() ) );
  
  $buttons = array(
    'vk' => array(
      'name'   => esc_html__( 'VK', 'nsafb' ),
      'url'    => 'http://vk.com/share.php?url=' . $post_permalink . '&amp;title=' . $title . '&amp;description=' . $excerpt . '&amp;image=' . $thumbnail_src,
      'title'  => esc_html__( 'Share on Vk', 'nsafb' ),
      'icon'   => nsafb_get_svg( 'vk' ),
      'show'   => 0
     ),
    'facebook' => array(
      'name'   => esc_html__( 'Facebook', 'nsafb' ),
      'url'    => 'http://www.facebook.com/sharer/sharer.php?u=' . $post_permalink,
      'title'  => esc_html__( 'Share on Facebook', 'nsafb' ),
      'icon'   => nsafb_get_svg( 'facebook' ),
      'show'   => 1
     ),
    'twitter' => array(
      'name'   => esc_html__( 'Twitter', 'nsafb' ),
      'url'    => 'https://twitter.com/intent/tweet?text=' . $title . '&amp;url=' . $post_permalink,
      'title'  => esc_html__( 'Tweet It', 'nsafb' ),
      'icon'   => nsafb_get_svg( 'twitter' ),
      'show'   => 1
     ),
    'pinterest' => array(
      'name'   => esc_html__( 'Pinterest', 'nsafb' ),
      'url'    => 'https://www.pinterest.com/pin/create/button/?description=' . $title . '&amp;media=' . $thumbnail_src . '&amp;url=' . $post_permalink,
      'title'  => esc_html__( 'Pin It', 'nsafb' ),
      'icon'   => nsafb_get_svg( 'pinterest' ),
      'show'   => 0
     ),
    'tumblr' => array(
      'name'   => esc_html__( 'Tumblr', 'nsafb' ),
      'url'    => 'http://www.tumblr.com/share/link?url=' . $post_permalink . '&amp;name=' . $title . '&amp;description=' . $excerpt,
      'title'  => esc_html__( 'Post on Tumblr', 'nsafb' ),
      'icon'   => nsafb_get_svg( 'tumblr' ),
      'show'   => 0
     ),
    'reddit' => array(
      'name'   => esc_html__( 'Reddit', 'nsafb' ),
      'url'    => 'https://www.reddit.com/submit?url=' . $post_permalink,
      'title'  => esc_html__( 'Share on Reddit', 'nsafb' ),
      'icon'   => nsafb_get_svg( 'reddit' ),
      'show'   => 0
     ),
    'linkedin' => array(
      'name'   => esc_html__( 'LinkedIn', 'nsafb' ),
      'url'    => 'https://www.linkedin.com/shareArticle?url=' . $post_permalink . '&amp;title=' . $title . '&amp;summary=' . $excerpt,
      'title'  => esc_html__( 'Share on LinkedIn', 'nsafb' ),
      'icon'   => nsafb_get_svg( 'linkedin' ),
      'show'   => 0
     )
  );
  
  $output = '';

  foreach( $buttons as $button_id => $button_data ) {
    if( get_theme_mod( 'nsafb_display_' . $button_id . '_share_button', $button_data['show'] ) ) {
      $output .= sprintf( '
        <a href="%s" title="%s" class="nsafb-share-button nsafb-%s-share-button %s" rel="nofollow">%s%s</a>', 
        esc_url( $button_data['url'] ), 
        esc_attr( $button_data['title'] ), 
        esc_attr( $button_id ),
        $display_name ? 'nsafb-has-name' : '', 
        $display_icon ? sprintf( '<div class="nsafb-share-button-icon">%s</div>', $button_data['icon'] ) : '', 
        $display_name ? sprintf( '<div class="nsafb-share-button-name">%s</div>', esc_attr( $button_data['name'] ) ) : ''
      );
    }
  } 
  
  if( $output )
    return sprintf( '<div class="nsafb-share-buttons">%s</div>', $output );
}

/**
 * Display author social profiles and conacts.
 *
 * @since Nord Share and Follow Buttons 1.0
 */
function nsafb_user_contact_links( $before = '', $after = '' ) {
  $output = '';

  $url = get_the_author_meta( 'url' );

  if( $url ) {
    $output .= sprintf( 
      '<a href="%s" title="%s" class="nsafb-contact-link nsafb-contact-link-url" target="_blank">%s</a>', 
      esc_url( $url ),
      esc_html__( 'Website', 'nsafb' ),
      nsafb_get_svg( 'website' )
    );
  }

  $contact_methods = apply_filters( 'nsafb_social_networks', 
    array(
      'facebook'   => esc_html__( 'Facebook', 'nsafb' ),
      'twitter'    => esc_html__( 'Twitter', 'nsafb' ),
      'google'     => esc_html__( 'Google', 'nsafb' ),
      'instagram'  => esc_html__( 'Instagram', 'nsafb' ),
      'pinterest'  => esc_html__( 'Pinterest', 'nsafb' ),
      'reddit'     => esc_html__( 'Reddit', 'nsafb' ),
      'linkedin'   => esc_html__( 'LinkedIn', 'nsafb' ),
      'vk'         => esc_html__( 'VK', 'nsafb' ),
      'dribbble'   => esc_html__( 'Dribbble', 'nsafb' ),
      'behance'    => esc_html__( 'Behance', 'nsafb' ),
      'tumblr'     => esc_html__( 'Tumblr', 'nsafb' ),
      'medium'     => esc_html__( 'Medium', 'nsafb' ),
      'flickr'     => esc_html__( 'Flickr', 'nsafb' ),
      'github'     => esc_html__( 'Github', 'nsafb' ),
      'youtube'    => esc_html__( 'YouTube', 'nsafb' ),
      'soundcloud' => esc_html__( 'SoundCloud', 'nsafb' ),
      'secondary_email' => esc_html__( 'Email', 'nsafb' )
    ) 
  );

  if( $contact_methods ) {
    foreach( $contact_methods as $contact_method_id => $contact_method_name ) {
      $contact_value = get_the_author_meta( $contact_method_id );

      if( $contact_value ) {
        if( $contact_method_id == 'secondary_email' ) {
          $contact_value = is_email( $contact_value ) ? $contact_value : '';
        } else {
          $contact_value = esc_url( $contact_value );
        }

        if( $contact_value ) {
          $output .= sprintf( 
            '<a href="%s" title="%s" class="nsafb-contact-link nsafb-contact-link-%s" %s>%s</a>', 
            ( $contact_method_id == 'secondary_email' ) ? 'mailto:' . $contact_value : $contact_value, 
            $contact_method_name, 
            $contact_method_id,
            ( $contact_method_id == 'secondary_email' ) ? '' : 'target="_blank"',
            nsafb_get_svg( $contact_method_id )
          );
        }
      }
    }
  }

  if( $output ) {
    wp_enqueue_style( 'nord-share-and-follow-buttons' );

    printf( '%s<div class="nsafb-author-links">%s</div>%s', $before, $output, $after );
  }
}

/**
 * Modify default user contact links.
 *
 * @since Nord Share and Follow Buttons 1.0
 */
function nsafb_modify_contact_methods( $profile_fields ) {
    $contact_methods = apply_filters( 'nsafb_social_networks', 
      array(
        'facebook'   => esc_html__( 'Facebook', 'nsafb' ),
        'twitter'    => esc_html__( 'Twitter', 'nsafb' ),
        'google'     => esc_html__( 'Google', 'nsafb' ),
        'instagram'  => esc_html__( 'Instagram', 'nsafb' ),
        'pinterest'  => esc_html__( 'Pinterest', 'nsafb' ),
        'linkedin'   => esc_html__( 'LinkedIn', 'nsafb' ),
        'vk'         => esc_html__( 'VK', 'nsafb' ),
        'dribbble'   => esc_html__( 'Dribbble', 'nsafb' ),
        'behance'    => esc_html__( 'Behance', 'nsafb' ),
        'tumblr'     => esc_html__( 'Tumblr', 'nsafb' ),
        'medium'     => esc_html__( 'Medium', 'nsafb' ),
        'flickr'     => esc_html__( 'Flickr', 'nsafb' ),
        'github'     => esc_html__( 'Github', 'nsafb' ),
        'youtube'    => esc_html__( 'YouTube', 'nsafb' ),
        'soundcloud' => esc_html__( 'SoundCloud', 'nsafb' ),
        'secondary_email' => esc_html__( 'Email', 'nsafb' )
      ) 
    );

    if( $contact_methods ) {
      foreach( $contact_methods as $contact_method_id => $contact_method_name ) {
        $profile_fields[ $contact_method_id ] = $contact_method_name;
      }
    }

    return $profile_fields;
}

add_filter( 'user_contactmethods', 'nsafb_modify_contact_methods' );

/**
 * HTML output for social profile icons.
 *
 * @since Nord Share and Follow Buttons 1.0
 *
 */
function nsafb_social_profiles( $before = '', $after = '' ) {
  $social_profiles = get_theme_mod( 'nsafb_social_profiles' );
  
  if( empty( $social_profiles ) )
    return;
  
  $output = '';
  
  if( is_array( $social_profiles ) ) {
    foreach( $social_profiles as $network_id => $url ) {
      if( $url )
        $output .= sprintf( 
          '<a href="%s" class="%s" target="_blank">%s</a>', 
          ( $network_id == 'email' ) ? 'mailto:' . esc_attr( $url ) : esc_url( $url ), 
          esc_attr( $network_id ),
          nsafb_get_svg( $network_id )
       );
    }
  }
  
  if( $output ) {
    wp_enqueue_style( 'nord-share-and-follow-buttons' );
    printf( '%s<div class="nsafb-social-profiles">%s</div>%s', $before, $output, $after );

  }
}

/**
 * Implement Customizer additions and adjustments.
 *
 * @since Nord Share and Follow Buttons 1.0
 *
 * @param WP_Customize_Manager $wp_customize Customizer object.
 */
function nsafb_customize_register( $wp_customize ) {

  // Share Buttons - Display Options
  $wp_customize->add_section( 'nsafb_share_buttons',
    array(
      'title' => esc_html__( 'Share Buttons', 'nsafb' )
    )
  ); 
  
  $wp_customize->add_setting( 'nsafb_display_facebook_share_button',
    array(
      'default' => 1,
      'sanitize_callback' => 'nsafb_checkbox_sanitize',
    )
  );
  
  $wp_customize->add_control( 'nsafb_display_facebook_share_button', array(
    'type'     => 'checkbox',
    'priority' => 0,
    'label'    => esc_html__( 'Facebook', 'nsafb' ),
    'section'  => 'nsafb_share_buttons',
  ) );
  
  $wp_customize->add_setting( 'nsafb_display_twitter_share_button',
    array(
      'default' => 1,
      'sanitize_callback' => 'nsafb_checkbox_sanitize',
    )
  );
  
  $wp_customize->add_control( 'nsafb_display_twitter_share_button', array(
    'type'     => 'checkbox',
    'priority' => 5,
    'label'    => esc_html__( 'Twitter', 'nsafb' ),
    'section'  => 'nsafb_share_buttons',
  ) );
  
  $wp_customize->add_setting( 'nsafb_display_reddit_share_button',
    array(
      'default' => 0,
      'sanitize_callback' => 'nsafb_checkbox_sanitize',
    )
  );
  
  $wp_customize->add_control( 'nsafb_display_reddit_share_button', array(
    'type'     => 'checkbox',
    'priority' => 10,
    'label'    => esc_html__( 'Reddit', 'nsafb' ),
    'section'  => 'nsafb_share_buttons',
  ) );
  
  $wp_customize->add_setting( 'nsafb_display_pinterest_share_button',
    array(
      'default' => 0,
      'sanitize_callback' => 'nsafb_checkbox_sanitize',
    )
  );
  
  $wp_customize->add_control( 'nsafb_display_pinterest_share_button', array(
    'type'     => 'checkbox',
    'priority' => 15,
    'label'    => esc_html__( 'Pinterest', 'nsafb' ),
    'section'  => 'nsafb_share_buttons',
  ) );
  
  $wp_customize->add_setting( 'nsafb_display_tumblr_share_button',
    array(
      'default' => 0,
      'sanitize_callback' => 'nsafb_checkbox_sanitize',
    )
  );
  
  $wp_customize->add_control( 'nsafb_display_tumblr_share_button', array(
    'type'     => 'checkbox',
    'priority' => 20,
    'label'    => esc_html__( 'Tumblr', 'nsafb' ),
    'section'  => 'nsafb_share_buttons',
  ) );
  
  $wp_customize->add_setting( 'nsafb_display_linkedin_share_button',
    array(
      'default' => 0,
      'sanitize_callback' => 'nsafb_checkbox_sanitize',
    )
  );
  
  $wp_customize->add_control( 'nsafb_display_linkedin_share_button', array(
    'type'     => 'checkbox',
    'priority' => 25,
    'label'    => esc_html__( 'LinkedIn', 'nsafb' ),
    'section'  => 'nsafb_share_buttons',
  ) );

  $wp_customize->add_setting( 'nsafb_display_vk_share_button',
    array(
      'default' => 0,
      'sanitize_callback' => 'nsafb_checkbox_sanitize',
    )
  );
  
  $wp_customize->add_control( 'nsafb_display_vk_share_button', array(
    'type'     => 'checkbox',
    'priority' => 30,
    'label'    => esc_html__( 'VK', 'nsafb' ),
    'section'  => 'nsafb_share_buttons',
  ) );

  /* Social Profiles */

  $wp_customize->add_section( 'nsafb_social_profiles',
    array(
      'title' => esc_html__( 'Social Profiles', 'nsafb' )
    )
  );

  $wp_customize->add_setting( 'nsafb_social_profiles[facebook]',
    array(
      'default' => '',
      'sanitize_callback' => 'esc_url_raw'
    )
  );
  
  $wp_customize->add_control( 'nsafb_social_profiles[facebook]', array(
    'type'     => 'url',
    'priority' => 10,
    'section'  => 'nsafb_social_profiles',
    'label'    => esc_html__( 'Facebook', 'nsafb' ),
  ) );
  
  $wp_customize->add_setting( 'nsafb_social_profiles[twitter]',
    array(
      'default' => '',
      'sanitize_callback' => 'esc_url_raw'
    )
  );
  
  $wp_customize->add_control( 'nsafb_social_profiles[twitter]', array(
    'type'     => 'url',
    'priority' => 15,
    'section'  => 'nsafb_social_profiles',
    'label'    => esc_html__( 'Twitter', 'nsafb' ),
  ) );
  
  $wp_customize->add_setting( 'nsafb_social_profiles[google]',
    array(
      'default' => '',
      'sanitize_callback' => 'esc_url_raw'
    )
  );
  
  $wp_customize->add_control( 'nsafb_social_profiles[google]', array(
    'type'     => 'url',
    'priority' => 20,
    'section'  => 'nsafb_social_profiles',
    'label'    => esc_html__( 'Google', 'nsafb' ),
  ) );
  
  $wp_customize->add_setting( 'nsafb_social_profiles[bloglovin]',
    array(
      'default' => '',
      'sanitize_callback' => 'esc_url_raw'
    )
  );
  
  $wp_customize->add_control( 'nsafb_social_profiles[bloglovin]', array(
    'type'     => 'url',
    'priority' => 20,
    'section'  => 'nsafb_social_profiles',
    'label'    => esc_html__( 'Bloglovin', 'nsafb' ),
  ) );
  
  $wp_customize->add_setting( 'nsafb_social_profiles[instagram]',
    array(
      'default' => '',
      'sanitize_callback' => 'esc_url_raw'
    )
  );
  
  $wp_customize->add_control( 'nsafb_social_profiles[instagram]', array(
    'type'     => 'url',
    'priority' => 25,
    'section'  => 'nsafb_social_profiles',
    'label'    => esc_html__( 'Instagram', 'nsafb' ),
  ) );
  
  $wp_customize->add_setting( 'nsafb_social_profiles[pinterest]',
    array(
      'default' => '',
      'sanitize_callback' => 'esc_url_raw'
    )
  );
  
  $wp_customize->add_control( 'nsafb_social_profiles[pinterest]', array(
    'type'     => 'url',
    'priority' => 30,
    'section'  => 'nsafb_social_profiles',
    'label'    => esc_html__( 'Pinterest', 'nsafb' ),
  ) );
  
  $wp_customize->add_setting( 'nsafb_social_profiles[linkedin]',
    array(
      'default' => '',
      'sanitize_callback' => 'esc_url_raw'
    )
  );
  
  $wp_customize->add_control( 'nsafb_social_profiles[linkedin]', array(
    'type'     => 'url',
    'priority' => 35,
    'section'  => 'nsafb_social_profiles',
    'label'    => esc_html__( 'LinkedIn', 'nsafb' ),
  ) );
  
  $wp_customize->add_setting( 'nsafb_social_profiles[flickr]',
    array(
      'default' => '',
      'sanitize_callback' => 'esc_url_raw'
    )
  );
  
  $wp_customize->add_control( 'nsafb_social_profiles[flickr]', array(
    'type'     => 'url',
    'priority' => 40,
    'section'  => 'nsafb_social_profiles',
    'label'    => esc_html__( 'Flickr', 'nsafb' ),
  ) );
  
  $wp_customize->add_setting( 'nsafb_social_profiles[medium]',
    array(
      'default' => '',
      'sanitize_callback' => 'esc_url_raw'
    )
  );
  
  $wp_customize->add_control( 'nsafb_social_profiles[medium]', array(
    'type'     => 'url',
    'priority' => 45,
    'section'  => 'nsafb_social_profiles',
    'label'    => esc_html__( 'Medium', 'nsafb' ),
  ) );
  
  $wp_customize->add_setting( 'nsafb_social_profiles[vk]',
    array(
      'default' => '',
      'sanitize_callback' => 'esc_url_raw'
    )
  );
  
  $wp_customize->add_control( 'nsafb_social_profiles[vk]', array(
    'type'     => 'url',
    'priority' => 50,
    'section'  => 'nsafb_social_profiles',
    'label'    => esc_html__( 'VK', 'nsafb' ),
  ) );
  
  $wp_customize->add_setting( 'nsafb_social_profiles[f500px]',
    array(
      'default' => '',
      'sanitize_callback' => 'esc_url_raw'
    )
  );
  
  $wp_customize->add_control( 'nsafb_social_profiles[f500px]', array(
    'type'     => 'url',
    'priority' => 55,
    'section'  => 'nsafb_social_profiles',
    'label'    => esc_html__( '500px', 'nsafb' ),
  ) );
  
  $wp_customize->add_setting( 'nsafb_social_profiles[tumblr]',
    array(
      'default' => '',
      'sanitize_callback' => 'esc_url_raw'
    )
  );
  
  $wp_customize->add_control( 'nsafb_social_profiles[tumblr]', array(
    'type'     => 'url',
    'priority' => 60,
    'section'  => 'nsafb_social_profiles',
    'label'    => esc_html__( 'Tumblr', 'nsafb' ),
  ) );
  
  $wp_customize->add_setting( 'nsafb_social_profiles[dribbble]',
    array(
      'default' => '',
      'sanitize_callback' => 'esc_url_raw'
    )
  );
  
  $wp_customize->add_control( 'nsafb_social_profiles[dribbble]', array(
    'type'     => 'url',
    'priority' => 65,
    'section'  => 'nsafb_social_profiles',
    'label'    => esc_html__( 'Dribbble', 'nsafb' ),
  ) );
  
  $wp_customize->add_setting( 'nsafb_social_profiles[behance]',
    array(
      'default' => '',
      'sanitize_callback' => 'esc_url_raw'
    )
  );
  
  $wp_customize->add_control( 'nsafb_social_profiles[behance]', array(
    'type'     => 'url',
    'priority' => 70,
    'section'  => 'nsafb_social_profiles',
    'label'    => esc_html__( 'Behance', 'nsafb' ),
  ) );
  
  $wp_customize->add_setting( 'nsafb_social_profiles[youtube]',
    array(
      'default' => '',
      'sanitize_callback' => 'esc_url_raw'
    )
  );
  
  $wp_customize->add_control( 'nsafb_social_profiles[youtube]', array(
    'type'     => 'url',
    'priority' => 75,
    'section'  => 'nsafb_social_profiles',
    'label'    => esc_html__( 'YouTube', 'nsafb' ),
  ) );
  
  $wp_customize->add_setting( 'nsafb_social_profiles[vimeo]',
    array(
      'default' => '',
      'sanitize_callback' => 'esc_url_raw'
    )
  );
  
  $wp_customize->add_control( 'nsafb_social_profiles[vimeo]', array(
    'type'     => 'url',
    'priority' => 80,
    'section'  => 'nsafb_social_profiles',
    'label'    => esc_html__( 'Vimeo', 'nsafb' ),
  ) );
  
  $wp_customize->add_setting( 'nsafb_social_profiles[github]',
    array(
      'default' => '',
      'sanitize_callback' => 'esc_url_raw'
    )
  );
  
  $wp_customize->add_control( 'nsafb_social_profiles[github]', array(
    'type'     => 'url',
    'priority' => 85,
    'section'  => 'nsafb_social_profiles',
    'label'    => esc_html__( 'Github', 'nsafb' ),
  ) );
  
  $wp_customize->add_setting( 'nsafb_social_profiles[soundcloud]',
    array(
      'default' => '',
      'sanitize_callback' => 'esc_url_raw'
    )
  );
  
  $wp_customize->add_control( 'nsafb_social_profiles[soundcloud]', array(
    'type'     => 'url',
    'priority' => 90,
    'section'  => 'nsafb_social_profiles',
    'label'    => esc_html__( 'SoundCloud', 'nsafb' ),
  ) );
  
  $wp_customize->add_setting( 'nsafb_social_profiles[rss]',
    array(
      'default' => '',
      'sanitize_callback' => 'esc_url_raw'
    )
  );
  
  $wp_customize->add_control( 'nsafb_social_profiles[rss]', array(
    'type'     => 'url',
    'priority' => 95,
    'section'  => 'nsafb_social_profiles',
    'label'    => esc_html__( 'Rss', 'nsafb' ),
  ) );

  $wp_customize->add_setting( 'nsafb_social_profiles[etsy]',
    array(
      'default' => '',
      'sanitize_callback' => 'esc_url_raw'
    )
  );
  
  $wp_customize->add_control( 'nsafb_social_profiles[etsy]', array(
    'type'     => 'url',
    'priority' => 100,
    'section'  => 'nsafb_social_profiles',
    'label'    => esc_html__( 'Etsy', 'nsafb' ),
  ) );

  $wp_customize->add_setting( 'nsafb_social_profiles[steam]',
    array(
      'default' => '',
      'sanitize_callback' => 'esc_url_raw'
    )
  );
  
  $wp_customize->add_control( 'nsafb_social_profiles[steam]', array(
    'type'     => 'url',
    'priority' => 105,
    'section'  => 'nsafb_social_profiles',
    'label'    => esc_html__( 'Steam', 'nsafb' ),
  ) );

  $wp_customize->add_setting( 'nsafb_social_profiles[snapchat]',
    array(
      'default' => '',
      'sanitize_callback' => 'esc_url_raw'
    )
  );
  
  $wp_customize->add_control( 'nsafb_social_profiles[snapchat]', array(
    'type'     => 'url',
    'priority' => 110,
    'section'  => 'nsafb_social_profiles',
    'label'    => esc_html__( 'Snapchat', 'nsafb' ),
  ) );

  $wp_customize->add_setting( 'nsafb_social_profiles[twitch]',
    array(
      'default' => '',
      'sanitize_callback' => 'esc_url_raw'
    )
  );
  
  $wp_customize->add_control( 'nsafb_social_profiles[twitch]', array(
    'type'     => 'url',
    'priority' => 115,
    'section'  => 'nsafb_social_profiles',
    'label'    => esc_html__( 'Twitch', 'nsafb' ),
  ) );

  $wp_customize->add_setting( 'nsafb_social_profiles[quora]',
    array(
      'default' => '',
      'sanitize_callback' => 'esc_url_raw'
    )
  );
  
  $wp_customize->add_control( 'nsafb_social_profiles[quora]', array(
    'type'     => 'url',
    'priority' => 120,
    'section'  => 'nsafb_social_profiles',
    'label'    => esc_html__( 'Quora', 'nsafb' ),
  ) );

  $wp_customize->add_setting( 'nsafb_social_profiles[odnoklassniki]',
    array(
      'default' => '',
      'sanitize_callback' => 'esc_url_raw'
    )
  );
  
  $wp_customize->add_control( 'nsafb_social_profiles[odnoklassniki]', array(
    'type'     => 'url',
    'priority' => 125,
    'section'  => 'nsafb_social_profiles',
    'label'    => esc_html__( 'Odnoklassniki', 'nsafb' ),
  ) );

  $wp_customize->add_setting( 'nsafb_social_profiles[reddit]',
    array(
      'default' => '',
      'sanitize_callback' => 'esc_url_raw'
    )
  );
  
  $wp_customize->add_control( 'nsafb_social_profiles[reddit]', array(
    'type'     => 'url',
    'priority' => 130,
    'section'  => 'nsafb_social_profiles',
    'label'    => esc_html__( 'Reddit', 'nsafb' ),
  ) );

  $wp_customize->add_setting( 'nsafb_social_profiles[xing]',
    array(
      'default' => '',
      'sanitize_callback' => 'esc_url_raw'
    )
  );
  
  $wp_customize->add_control( 'nsafb_social_profiles[xing]', array(
    'type'     => 'url',
    'priority' => 135,
    'section'  => 'nsafb_social_profiles',
    'label'    => esc_html__( 'Xing', 'nsafb' ),
  ) );
  
  $wp_customize->add_setting( 'nsafb_social_profiles[weibo]',
    array(
      'default' => '',
      'sanitize_callback' => 'esc_url_raw'
    )
  );

  $wp_customize->add_control( 'nsafb_social_profiles[weibo]', array(
    'type'     => 'url',
    'priority' => 135,
    'section'  => 'nsafb_social_profiles',
    'label'    => esc_html__( 'Weibo', 'nsafb' ),
  ) );

  $wp_customize->add_setting( 'nsafb_social_profiles[renren]',
    array(
      'default' => '',
      'sanitize_callback' => 'esc_url_raw'
    )
  );

  $wp_customize->add_control( 'nsafb_social_profiles[renren]', array(
    'type'     => 'url',
    'priority' => 140,
    'section'  => 'nsafb_social_profiles',
    'label'    => esc_html__( 'Renren', 'nsafb' ),
  ) );

  $wp_customize->add_setting( 'nsafb_social_profiles[spotify]',
    array(
      'default' => '',
      'sanitize_callback' => 'esc_url_raw'
    )
  );

  $wp_customize->add_control( 'nsafb_social_profiles[spotify]', array(
    'type'     => 'url',
    'priority' => 140,
    'section'  => 'nsafb_social_profiles',
    'label'    => esc_html__( 'Spotify', 'nsafb' ),
  ) );
  
  $wp_customize->add_setting( 'nsafb_social_profiles[email]',
    array(
      'default' => '',
      'sanitize_callback' => 'nsafb_email_sanitize'
    )
  );
  
  $wp_customize->add_control( 'nsafb_social_profiles[email]', array(
    'type'     => 'email',
    'priority' => 150,
    'section'  => 'nsafb_social_profiles',
    'label'    => esc_html__( 'Email', 'nsafb' ),
  ) );
}

add_action( 'customize_register', 'nsafb_customize_register' );

/**
 * Sanitize boolean for checkbox.
 *
 * @param bool $checked Whether or not a box is checked.
 *
 * @return bool
 */
function nsafb_checkbox_sanitize( $checked ) {
  return ( ( isset( $checked ) && true === $checked ) ? true : false );
}

/**
 * Sanitization callback for email field.
 *
 * @return string|null Verified email adress or null.
 */
function nsafb_email_sanitize( $value ) {
  return ( is_email( $value ) ) ? $value : '';
}

function nsafb_get_svg_html( $svg_name ) {
  // SVG pathes from Font Awesome 4.7 https://github.com/encharm/Font-Awesome-SVG-PNG/tree/master/black/svg
  $svgs = array(
    'facebook' => '<svg class="nsafb-svg-icon" width="30" height="30" viewBox="0 0 1792 1792" xmlns="http://www.w3.org/2000/svg">
      <path d="M1343 12v264h-157q-86 0-116 36t-30 108v189h293l-39 296h-254v759h-306v-759h-255v-296h255v-218q0-186 104-288.5t277-102.5q147 0 228 12z"/>
    </svg>',
    'twitter' => '<svg class="nsafb-svg-icon" width="30" height="30" viewBox="0 0 1792 1792" xmlns="http://www.w3.org/2000/svg">
      <path d="M1684 408q-67 98-162 167 1 14 1 42 0 130-38 259.5t-115.5 248.5-184.5 210.5-258 146-323 54.5q-271 0-496-145 35 4 78 4 225 0 401-138-105-2-188-64.5t-114-159.5q33 5 61 5 43 0 85-11-112-23-185.5-111.5t-73.5-205.5v-4q68 38 146 41-66-44-105-115t-39-154q0-88 44-163 121 149 294.5 238.5t371.5 99.5q-8-38-8-74 0-134 94.5-228.5t228.5-94.5q140 0 236 102 109-21 205-78-37 115-142 178 93-10 186-50z"/>
    </svg>',
    'google' => '<svg class="nsafb-svg-icon" width="30" height="30" viewBox="0 0 1792 1792" xmlns="http://www.w3.org/2000/svg">
      <path d="M896 786h725q12 67 12 128 0 217-91 387.5t-259.5 266.5-386.5 96q-157 0-299-60.5t-245-163.5-163.5-245-60.5-299 60.5-299 163.5-245 245-163.5 299-60.5q300 0 515 201l-209 201q-123-119-306-119-129 0-238.5 65t-173.5 176.5-64 243.5 64 243.5 173.5 176.5 238.5 65q87 0 160-24t120-60 82-82 51.5-87 22.5-78h-436v-264z"/>
    </svg>',
    'bloglovin' => '<svg class="nsafb-svg-icon" width="30" height="30" viewBox="0 0 1792 1792" xmlns="http://www.w3.org/2000/svg">
      <path d="M896 1664q-26 0-44-18l-624-602q-10-8-27.5-26t-55.5-65.5-68-97.5-53.5-121-23.5-138q0-220 127-344t351-124q62 0 126.5 21.5t120 58 95.5 68.5 76 68q36-36 76-68t95.5-68.5 120-58 126.5-21.5q224 0 351 124t127 344q0 221-229 450l-623 600q-18 18-44 18z"/>
    </svg>',
    'instagram' => '<svg class="nsafb-svg-icon" width="30" height="30" viewBox="0 0 1792 1792" xmlns="http://www.w3.org/2000/svg">
      <path d="M1152 896q0-106-75-181t-181-75-181 75-75 181 75 181 181 75 181-75 75-181zm138 0q0 164-115 279t-279 115-279-115-115-279 115-279 279-115 279 115 115 279zm108-410q0 38-27 65t-65 27-65-27-27-65 27-65 65-27 65 27 27 65zm-502-220q-7 0-76.5-.5t-105.5 0-96.5 3-103 10-71.5 18.5q-50 20-88 58t-58 88q-11 29-18.5 71.5t-10 103-3 96.5 0 105.5.5 76.5-.5 76.5 0 105.5 3 96.5 10 103 18.5 71.5q20 50 58 88t88 58q29 11 71.5 18.5t103 10 96.5 3 105.5 0 76.5-.5 76.5.5 105.5 0 96.5-3 103-10 71.5-18.5q50-20 88-58t58-88q11-29 18.5-71.5t10-103 3-96.5 0-105.5-.5-76.5.5-76.5 0-105.5-3-96.5-10-103-18.5-71.5q-20-50-58-88t-88-58q-29-11-71.5-18.5t-103-10-96.5-3-105.5 0-76.5.5zm768 630q0 229-5 317-10 208-124 322t-322 124q-88 5-317 5t-317-5q-208-10-322-124t-124-322q-5-88-5-317t5-317q10-208 124-322t322-124q88-5 317-5t317 5q208 10 322 124t124 322q5 88 5 317z"/>
    </svg>',
    'pinterest' => '<svg class="nsafb-svg-icon" width="30" height="30" viewBox="0 0 1792 1792" xmlns="http://www.w3.org/2000/svg">
      <path d="M1664 896q0 209-103 385.5t-279.5 279.5-385.5 103q-111 0-218-32 59-93 78-164 9-34 54-211 20 39 73 67.5t114 28.5q121 0 216-68.5t147-188.5 52-270q0-114-59.5-214t-172.5-163-255-63q-105 0-196 29t-154.5 77-109 110.5-67 129.5-21.5 134q0 104 40 183t117 111q30 12 38-20 2-7 8-31t8-30q6-23-11-43-51-61-51-151 0-151 104.5-259.5t273.5-108.5q151 0 235.5 82t84.5 213q0 170-68.5 289t-175.5 119q-61 0-98-43.5t-23-104.5q8-35 26.5-93.5t30-103 11.5-75.5q0-50-27-83t-77-33q-62 0-105 57t-43 142q0 73 25 122l-99 418q-17 70-13 177-206-91-333-281t-127-423q0-209 103-385.5t279.5-279.5 385.5-103 385.5 103 279.5 279.5 103 385.5z"/>
    </svg>',
    'linkedin' => '<svg class="nsafb-svg-icon" width="30" height="30" viewBox="0 0 1792 1792" xmlns="http://www.w3.org/2000/svg">
      <path d="M477 625v991h-330v-991h330zm21-306q1 73-50.5 122t-135.5 49h-2q-82 0-132-49t-50-122q0-74 51.5-122.5t134.5-48.5 133 48.5 51 122.5zm1166 729v568h-329v-530q0-105-40.5-164.5t-126.5-59.5q-63 0-105.5 34.5t-63.5 85.5q-11 30-11 81v553h-329q2-399 2-647t-1-296l-1-48h329v144h-2q20-32 41-56t56.5-52 87-43.5 114.5-15.5q171 0 275 113.5t104 332.5z"/>
    </svg>',
    'flickr' => '<svg class="nsafb-svg-icon" width="30" height="30" viewBox="0 0 1792 1792" xmlns="http://www.w3.org/2000/svg">
      <path d="M1376 128q119 0 203.5 84.5t84.5 203.5v960q0 119-84.5 203.5t-203.5 84.5h-960q-119 0-203.5-84.5t-84.5-203.5v-960q0-119 84.5-203.5t203.5-84.5h960zm-550 768q0-88-62-150t-150-62-150 62-62 150 62 150 150 62 150-62 62-150zm564 0q0-88-62-150t-150-62-150 62-62 150 62 150 150 62 150-62 62-150z"/>
    </svg>',
    'medium' => '<svg class="nsafb-svg-icon" width="30" height="30" viewBox="0 0 1792 1792" xmlns="http://www.w3.org/2000/svg">
      <path d="M597 421v1173q0 25-12.5 42.5t-36.5 17.5q-17 0-33-8l-465-233q-21-10-35.5-33.5t-14.5-46.5v-1140q0-20 10-34t29-14q14 0 44 15l511 256q3 3 3 5zm64 101l534 866-534-266v-600zm1131 18v1054q0 25-14 40.5t-38 15.5-47-13l-441-220zm-3-120q0 3-256.5 419.5t-300.5 487.5l-390-634 324-527q17-28 52-28 14 0 26 6l541 270q4 2 4 6z"/>
    </svg>',
    'f500px' => '<svg class="nsafb-svg-icon" width="30" height="30" viewBox="0 0 1792 1792" xmlns="http://www.w3.org/2000/svg">
      <path d="M1529 1547l-6 6q-113 113-259 175-154 64-317 64-165 0-317-64-148-63-259-175-113-112-175-258-42-103-54-189-4-28 48-36 51-8 56 20 1 1 1 4 18 90 46 159 50 124 152 226 98 98 226 152 132 56 276 56 143 0 276-56 128-55 225-152l6-6q10-10 25-6 12 3 33 22 36 37 17 58zm-472-615l-66 66 63 63q21 21-7 49-17 17-32 17-10 0-19-10l-62-61-66 66q-5 5-15 5-15 0-31-16l-2-2q-18-15-18-29 0-7 8-17l66-65-66-66q-16-16 14-45 18-18 31-18 6 0 13 5l65 66 65-65q18-17 48 13 27 27 11 44zm471 57q0 118-46 228-45 105-126 186-80 80-187 126t-228 46-228-46-187-126q-82-82-125-186-15-33-15-40h-1q-9-27 43-44 50-16 60 12 37 99 97 167h1v-341q3-136 102-232 105-103 253-103 147 0 251 103t104 249q0 147-104.5 251t-250.5 104q-58 0-112-16-28-11-13-61 16-51 44-43l14 3q14 3 33 6t30 3q104 0 176-71.5t72-174.5q0-101-72-171-71-71-175-71-107 0-178 80-64 72-64 160v413q110 67 242 67 96 0 185-36.5t156-103.5 103.5-155 36.5-183q0-198-141-339-140-140-339-140-200 0-340 140-53 53-77 87l-2 2q-8 11-13 15.5t-21.5 9.5-38.5-3q-21-5-36.5-16.5t-15.5-26.5v-680q0-15 10.5-26.5t27.5-11.5h877q30 0 30 55t-30 55h-811v483h1q40-42 102-84t108-61q109-46 231-46 121 0 228 46t187 126q81 81 126 186 46 112 46 229zm-31-581q9 8 9 18t-5.5 18-16.5 21q-26 26-39 26-9 0-16-7-106-91-207-133-128-56-276-56-133 0-262 49-27 10-45-37-9-25-8-38 3-16 16-20 130-57 299-57 164 0 316 64 137 58 235 152z"/>
    </svg>',
    'tumblr' => '<svg class="nsafb-svg-icon" width="30" height="30" viewBox="0 0 1792 1792" xmlns="http://www.w3.org/2000/svg">
      <path d="M1328 1329l80 237q-23 35-111 66t-177 32q-104 2-190.5-26t-142.5-74-95-106-55.5-120-16.5-118v-544h-168v-215q72-26 129-69.5t91-90 58-102 34-99 15-88.5q1-5 4.5-8.5t7.5-3.5h244v424h333v252h-334v518q0 30 6.5 56t22.5 52.5 49.5 41.5 81.5 14q78-2 134-29z"/>
    </svg>',
    'dribbble' => '<svg class="nsafb-svg-icon" width="30" height="30" viewBox="0 0 1792 1792" xmlns="http://www.w3.org/2000/svg">
      <path d="M1152 1500q-42-241-140-498h-2l-2 1q-16 6-43 16.5t-101 49-137 82-131 114.5-103 148l-15-11q184 150 418 150 132 0 256-52zm-185-607q-21-49-53-111-311 93-673 93-1 7-1 21 0 124 44 236.5t124 201.5q50-89 123.5-166.5t142.5-124.5 130.5-81 99.5-48l37-13q4-1 13-3.5t13-4.5zm-107-212q-120-213-244-378-138 65-234 186t-128 272q302 0 606-80zm684 319q-210-60-409-29 87 239 128 469 111-75 185-189.5t96-250.5zm-805-741q-1 0-2 1 1-1 2-1zm590 145q-185-164-433-164-76 0-155 19 131 170 246 382 69-26 130-60.5t96.5-61.5 65.5-57 37.5-40.5zm223 485q-3-232-149-410l-1 1q-9 12-19 24.5t-43.5 44.5-71 60.5-100 65-131.5 64.5q25 53 44 95 2 5 6.5 17t7.5 17q36-5 74.5-7t73.5-2 69 1.5 64 4 56.5 5.5 48 6.5 36.5 6 25 4.5zm112 7q0 209-103 385.5t-279.5 279.5-385.5 103-385.5-103-279.5-279.5-103-385.5 103-385.5 279.5-279.5 385.5-103 385.5 103 279.5 279.5 103 385.5z"/>
    </svg>',
    'behance' => '<svg class="nsafb-svg-icon" width="30" height="30" viewBox="0 0 2048 1792" xmlns="http://www.w3.org/2000/svg">
      <path d="M1848 339h-511v124h511v-124zm-252 426q-90 0-146 52.5t-62 142.5h408q-18-195-200-195zm16 585q63 0 122-32t76-87h221q-100 307-427 307-214 0-340.5-132t-126.5-347q0-208 130.5-345.5t336.5-137.5q138 0 240.5 68t153 179 50.5 248q0 17-2 47h-658q0 111 57.5 171.5t166.5 60.5zm-1335-50h296q205 0 205-167 0-180-199-180h-302v347zm0-537h281q78 0 123.5-36.5t45.5-113.5q0-144-190-144h-260v294zm-277-509h594q87 0 155 14t126.5 47.5 90 96.5 31.5 154q0 181-172 263 114 32 172 115t58 204q0 75-24.5 136.5t-66 103.5-98.5 71-121 42-134 13h-611v-1260z"/>
    </svg>',
    'youtube' => '<svg class="nsafb-svg-icon" width="30" height="30" viewBox="0 0 1792 1792" xmlns="http://www.w3.org/2000/svg">
      <path d="M711 1128l484-250-484-253v503zm185-862q168 0 324.5 4.5t229.5 9.5l73 4q1 0 17 1.5t23 3 23.5 4.5 28.5 8 28 13 31 19.5 29 26.5q6 6 15.5 18.5t29 58.5 26.5 101q8 64 12.5 136.5t5.5 113.5v176q1 145-18 290-7 55-25 99.5t-32 61.5l-14 17q-14 15-29 26.5t-31 19-28 12.5-28.5 8-24 4.5-23 3-16.5 1.5q-251 19-627 19-207-2-359.5-6.5t-200.5-7.5l-49-4-36-4q-36-5-54.5-10t-51-21-56.5-41q-6-6-15.5-18.5t-29-58.5-26.5-101q-8-64-12.5-136.5t-5.5-113.5v-176q-1-145 18-290 7-55 25-99.5t32-61.5l14-17q14-15 29-26.5t31-19.5 28-13 28.5-8 23.5-4.5 23-3 17-1.5q251-18 627-18z"/>
    </svg>',
    'vimeo' => '<svg class="nsafb-svg-icon" width="30" height="30" viewBox="0 0 1792 1792" xmlns="http://www.w3.org/2000/svg">
      <path d="M1709 518q-10 236-332 651-333 431-562 431-142 0-240-263-44-160-132-482-72-262-157-262-18 0-127 76l-77-98q24-21 108-96.5t130-115.5q156-138 241-146 95-9 153 55.5t81 203.5q44 287 66 373 55 249 120 249 51 0 154-161 101-161 109-246 13-139-109-139-57 0-121 26 120-393 459-382 251 8 236 326z"/>
    </svg>',
    'github' => '<svg class="nsafb-svg-icon" width="30" height="30" viewBox="0 0 1792 1792" xmlns="http://www.w3.org/2000/svg">
      <path d="M896 128q209 0 385.5 103t279.5 279.5 103 385.5q0 251-146.5 451.5t-378.5 277.5q-27 5-40-7t-13-30q0-3 .5-76.5t.5-134.5q0-97-52-142 57-6 102.5-18t94-39 81-66.5 53-105 20.5-150.5q0-119-79-206 37-91-8-204-28-9-81 11t-92 44l-38 24q-93-26-192-26t-192 26q-16-11-42.5-27t-83.5-38.5-85-13.5q-45 113-8 204-79 87-79 206 0 85 20.5 150t52.5 105 80.5 67 94 39 102.5 18q-39 36-49 103-21 10-45 15t-57 5-65.5-21.5-55.5-62.5q-19-32-48.5-52t-49.5-24l-20-3q-21 0-29 4.5t-5 11.5 9 14 13 12l7 5q22 10 43.5 38t31.5 51l10 23q13 38 44 61.5t67 30 69.5 7 55.5-3.5l23-4q0 38 .5 88.5t.5 54.5q0 18-13 30t-40 7q-232-77-378.5-277.5t-146.5-451.5q0-209 103-385.5t279.5-279.5 385.5-103zm-477 1103q3-7-7-12-10-3-13 2-3 7 7 12 9 6 13-2zm31 34q7-5-2-16-10-9-16-3-7 5 2 16 10 10 16 3zm30 45q9-7 0-19-8-13-17-6-9 5 0 18t17 7zm42 42q8-8-4-19-12-12-20-3-9 8 4 19 12 12 20 3zm57 25q3-11-13-16-15-4-19 7t13 15q15 6 19-6zm63 5q0-13-17-11-16 0-16 11 0 13 17 11 16 0 16-11zm58-10q-2-11-18-9-16 3-14 15t18 8 14-14z"/>
    </svg>',
    'soundcloud' => '<svg class="nsafb-svg-icon" width="30" height="30" viewBox="0 0 2304 1792" xmlns="http://www.w3.org/2000/svg">
      <path d="M784 1372l16-241-16-523q-1-10-7.5-17t-16.5-7q-9 0-16 7t-7 17l-14 523 14 241q1 10 7.5 16.5t15.5 6.5q22 0 24-23zm296-29l11-211-12-586q0-16-13-24-8-5-16-5t-16 5q-13 8-13 24l-1 6-10 579q0 1 11 236v1q0 10 6 17 9 11 23 11 11 0 20-9 9-7 9-20zm-1045-340l20 128-20 126q-2 9-9 9t-9-9l-17-126 17-128q2-9 9-9t9 9zm86-79l26 207-26 203q-2 9-10 9-9 0-9-10l-23-202 23-207q0-9 9-9 8 0 10 9zm280 453zm-188-491l25 245-25 237q0 11-11 11-10 0-12-11l-21-237 21-245q2-12 12-12 11 0 11 12zm94-7l23 252-23 244q-2 13-14 13-13 0-13-13l-21-244 21-252q0-13 13-13 12 0 14 13zm94 18l21 234-21 246q-2 16-16 16-6 0-10.5-4.5t-4.5-11.5l-20-246 20-234q0-6 4.5-10.5t10.5-4.5q14 0 16 15zm383 475zm-289-621l21 380-21 246q0 7-5 12.5t-12 5.5q-16 0-18-18l-18-246 18-380q2-18 18-18 7 0 12 5.5t5 12.5zm94-86l19 468-19 244q0 8-5.5 13.5t-13.5 5.5q-18 0-20-19l-16-244 16-468q2-19 20-19 8 0 13.5 5.5t5.5 13.5zm98-40l18 506-18 242q-2 21-22 21-19 0-21-21l-16-242 16-506q0-9 6.5-15.5t14.5-6.5q9 0 15 6.5t7 15.5zm392 742zm-198-746l15 510-15 239q0 10-7.5 17.5t-17.5 7.5-17-7-8-18l-14-239 14-510q0-11 7.5-18t17.5-7 17.5 7 7.5 18zm99 19l14 492-14 236q0 11-8 19t-19 8-19-8-9-19l-12-236 12-492q1-12 9-20t19-8 18.5 8 8.5 20zm212 492l-14 231q0 13-9 22t-22 9-22-9-10-22l-6-114-6-117 12-636v-3q2-15 12-24 9-7 20-7 8 0 15 5 14 8 16 26zm1112-19q0 117-83 199.5t-200 82.5h-786q-13-2-22-11t-9-22v-899q0-23 28-33 85-34 181-34 195 0 338 131.5t160 323.5q53-22 110-22 117 0 200 83t83 201z"/>
    </svg>',
    'rss' => '<svg class="nsafb-svg-icon" width="30" height="30" viewBox="0 0 1792 1792" xmlns="http://www.w3.org/2000/svg">
      <path d="M576 1344q0 80-56 136t-136 56-136-56-56-136 56-136 136-56 136 56 56 136zm512 123q2 28-17 48-18 21-47 21h-135q-25 0-43-16.5t-20-41.5q-22-229-184.5-391.5t-391.5-184.5q-25-2-41.5-20t-16.5-43v-135q0-29 21-47 17-17 43-17h5q160 13 306 80.5t259 181.5q114 113 181.5 259t80.5 306zm512 2q2 27-18 47-18 20-46 20h-143q-26 0-44.5-17.5t-19.5-42.5q-12-215-101-408.5t-231.5-336-336-231.5-408.5-102q-25-1-42.5-19.5t-17.5-43.5v-143q0-28 20-46 18-18 44-18h3q262 13 501.5 120t425.5 294q187 186 294 425.5t120 501.5z"/>
    </svg>',
    'etsy' => '<svg class="nsafb-svg-icon" width="30" height="30" viewBox="0 0 1792 1792" xmlns="http://www.w3.org/2000/svg">
      <path d="M646 183v655q103 1 191.5-1.5t125.5-5.5l37-3q68-2 90.5-24.5t39.5-94.5l33-142h103l-14 322 7 319h-103l-29-127q-15-68-45-93t-84-26q-87-8-352-8v556q0 78 43.5 115.5t133.5 37.5h357q35 0 59.5-2t55-7.5 54-18 48.5-32 46-50.5 39-73l93-216h89q-6 37-31.5 252t-30.5 276q-146-5-263.5-8t-162.5-4h-672l-376 12v-102l127-25q67-13 91.5-37t25.5-79l8-643q3-402-8-645-2-61-25.5-84t-91.5-36l-127-24v-102l376 12h702q139 0 374-27-6 68-14 194.5t-12 219.5l-5 92h-93l-32-124q-31-121-74-179.5t-113-58.5h-548q-28 0-35.5 8.5t-7.5 30.5z"/>
    </svg>',
    'steam' => '<svg class="nsafb-svg-icon" width="30" height="30" viewBox="0 0 1792 1792" xmlns="http://www.w3.org/2000/svg">
      <path d="M1582 582q0 101-71.5 172.5t-172.5 71.5-172.5-71.5-71.5-172.5 71.5-172.5 172.5-71.5 172.5 71.5 71.5 172.5zm-770 742q0-104-73-177t-177-73q-27 0-54 6l104 42q77 31 109.5 106.5t1.5 151.5q-31 77-107 109t-152 1q-21-8-62-24.5t-61-24.5q32 60 91 96.5t130 36.5q104 0 177-73t73-177zm830-741q0-126-89.5-215.5t-215.5-89.5q-127 0-216.5 89.5t-89.5 215.5q0 127 89.5 216t216.5 89q126 0 215.5-89t89.5-216zm150 0q0 189-133.5 322t-321.5 133l-437 319q-12 129-109 218t-229 89q-121 0-214-76t-118-192l-230-92v-429l389 157q79-48 173-48 13 0 35 2l284-407q2-187 135.5-319t320.5-132q188 0 321.5 133.5t133.5 321.5z"/>
    </svg>',
    'snapchat' => '<svg class="nsafb-svg-icon" width="30" height="30" viewBox="0 0 1792 1792" xmlns="http://www.w3.org/2000/svg">
      <path d="M1407 1148q0-22-22-27-67-15-118-59t-80-108q-7-19-7-25 0-15 19.5-26t43-17 43-20.5 19.5-36.5q0-19-18.5-31.5t-38.5-12.5q-12 0-32 8t-31 8q-4 0-12-2 5-95 5-114 0-79-17-114-36-78-103-121.5t-152-43.5q-199 0-275 165-17 35-17 114 0 19 5 114-4 2-14 2-12 0-32-7.5t-30-7.5q-21 0-38.5 12t-17.5 32q0 21 19.5 35.5t43 20.5 43 17 19.5 26q0 6-7 25-64 138-198 167-22 5-22 27 0 46 137 68 2 5 6 26t11.5 30.5 23.5 9.5q12 0 37.5-4.5t39.5-4.5q35 0 67 15t54 32.5 57.5 32.5 76.5 15q43 0 79-15t57.5-32.5 53.5-32.5 67-15q14 0 39.5 4t38.5 4q16 0 23-10t11-30 6-25q137-22 137-68zm257-252q0 209-103 385.5t-279.5 279.5-385.5 103-385.5-103-279.5-279.5-103-385.5 103-385.5 279.5-279.5 385.5-103 385.5 103 279.5 279.5 103 385.5z"/>
    </svg>',
    'twitch' => '<svg class="nsafb-svg-icon" width="30" height="30" viewBox="0 0 1792 1792" xmlns="http://www.w3.org/2000/svg">
      <path d="M896 434v434h-145v-434h145zm398 0v434h-145v-434h145zm0 760l253-254v-795h-1194v1049h326v217l217-217h398zm398-1194v1013l-434 434h-326l-217 217h-217v-217h-398v-1158l109-289h1483z"/>
    </svg>',
    'quora' => '<svg class="nsafb-svg-icon" width="30" height="30" viewBox="0 0 1792 1792" xmlns="http://www.w3.org/2000/svg">
      <path d="M1255 787q0-318-105-474.5t-330-156.5q-222 0-326 157t-104 474q0 316 104 471.5t326 155.5q74 0 131-17-22-43-39-73t-44-65-53.5-56.5-63-36-77.5-14.5q-46 0-79 16l-49-97q105-91 276-91 132 0 215.5 54t150.5 155q67-149 67-402zm390 632h117q3 27-2 67t-26.5 95-58 100.5-107 78-162.5 32.5q-71 0-130.5-19t-105.5-56-79-78-66-96q-97 27-205 27-150 0-292.5-58t-253-158.5-178-249-67.5-317.5q0-170 67.5-319.5t178.5-250.5 253.5-159 291.5-58q121 0 238.5 36t217 106 176 164.5 119.5 219 43 261.5q0 190-80.5 347.5t-218.5 264.5q47 70 93.5 106.5t104.5 36.5q61 0 94-37.5t38-85.5z"/>
    </svg>',
    'odnoklassniki' => '<svg class="nsafb-svg-icon" width="30" height="30" viewBox="0 0 1792 1792" xmlns="http://www.w3.org/2000/svg">
      <path d="M896 907q-188 0-321-133t-133-320q0-188 133-321t321-133 321 133 133 321q0 187-133 320t-321 133zm0-677q-92 0-157.5 65.5t-65.5 158.5q0 92 65.5 157.5t157.5 65.5 157.5-65.5 65.5-157.5q0-93-65.5-158.5t-157.5-65.5zm523 732q13 27 15 49.5t-4.5 40.5-26.5 38.5-42.5 37-61.5 41.5q-115 73-315 94l73 72 267 267q30 31 30 74t-30 73l-12 13q-31 30-74 30t-74-30q-67-68-267-268l-267 268q-31 30-74 30t-73-30l-12-13q-31-30-31-73t31-74l267-267 72-72q-203-21-317-94-39-25-61.5-41.5t-42.5-37-26.5-38.5-4.5-40.5 15-49.5q10-20 28-35t42-22 56 2 65 35q5 4 15 11t43 24.5 69 30.5 92 24 113 11q91 0 174-25.5t120-50.5l38-25q33-26 65-35t56-2 42 22 28 35z"/>
    </svg>',
    'reddit' => '<svg class="nsafb-svg-icon" width="30" height="30" viewBox="0 0 1792 1792" xmlns="http://www.w3.org/2000/svg">
      <path d="M1095 1167q16 16 0 31-62 62-199 62t-199-62q-16-15 0-31 6-6 15-6t15 6q48 49 169 49 120 0 169-49 6-6 15-6t15 6zm-307-181q0 37-26 63t-63 26-63.5-26-26.5-63q0-38 26.5-64t63.5-26 63 26.5 26 63.5zm395 0q0 37-26.5 63t-63.5 26-63-26-26-63 26-63.5 63-26.5 63.5 26 26.5 64zm251-120q0-49-35-84t-85-35-86 36q-130-90-311-96l63-283 200 45q0 37 26 63t63 26 63.5-26.5 26.5-63.5-26.5-63.5-63.5-26.5q-54 0-80 50l-221-49q-19-5-25 16l-69 312q-180 7-309 97-35-37-87-37-50 0-85 35t-35 84q0 35 18.5 64t49.5 44q-6 27-6 56 0 142 140 243t337 101q198 0 338-101t140-243q0-32-7-57 30-15 48-43.5t18-63.5zm358 30q0 182-71 348t-191 286-286 191-348 71-348-71-286-191-191-286-71-348 71-348 191-286 286-191 348-71 348 71 286 191 191 286 71 348z"/>
    </svg>',
    'vk' => '<svg class="nsafb-svg-icon" width="30" height="30" viewBox="0 0 2048 1792" xmlns="http://www.w3.org/2000/svg">
      <path d="M1981 520q23 64-150 294-24 32-65 85-40 51-55 72t-30.5 49.5-12 42 13 34.5 32.5 43 57 53q4 2 5 4 141 131 191 221 3 5 6.5 12.5t7 26.5-.5 34-25 27.5-59 12.5l-256 4q-24 5-56-5t-52-22l-20-12q-30-21-70-64t-68.5-77.5-61-58-56.5-15.5q-3 1-8 3.5t-17 14.5-21.5 29.5-17 52-6.5 77.5q0 15-3.5 27.5t-7.5 18.5l-4 5q-18 19-53 22h-115q-71 4-146-16.5t-131.5-53-103-66-70.5-57.5l-25-24q-10-10-27.5-30t-71.5-91-106-151-122.5-211-130.5-272q-6-16-6-27t3-16l4-6q15-19 57-19l274-2q12 2 23 6.5t16 8.5l5 3q16 11 24 32 20 50 46 103.5t41 81.5l16 29q29 60 56 104t48.5 68.5 41.5 38.5 34 14 27-5q2-1 5-5t12-22 13.5-47 9.5-81 0-125q-2-40-9-73t-14-46l-6-12q-25-34-85-43-13-2 5-24 16-19 38-30 53-26 239-24 82 1 135 13 20 5 33.5 13.5t20.5 24 10.5 32 3.5 45.5-1 55-2.5 70.5-1.5 82.5q0 11-1 42t-.5 48 3.5 40.5 11.5 39 22.5 24.5q8 2 17 4t26-11 38-34.5 52-67 68-107.5q60-104 107-225 4-10 10-17.5t11-10.5l4-3 5-2.5 13-3 20-.5 288-2q39-5 64 2.5t31 16.5z"/>
    </svg>',
    'xing' => '<svg class="nsafb-svg-icon" width="30" height="30" viewBox="0 0 1792 1792" xmlns="http://www.w3.org/2000/svg">
      <path d="M789 667q-10 18-257 456-27 46-65 46h-239q-21 0-31-17t0-36l253-448q1 0 0-1l-161-279q-12-22-1-37 9-15 32-15h239q40 0 66 45zm806-642q11 16 0 37l-528 934v1l336 615q11 20 1 37-10 15-32 15h-239q-42 0-66-45l-339-622q18-32 531-942 25-45 64-45h241q22 0 31 15z"/>
    </svg>',
    'weibo' => '<svg class="nsafb-svg-icon" width="30" height="30" viewBox="0 0 1792 1792" xmlns="http://www.w3.org/2000/svg">
      <path d="M675 1284q21-34 11-69t-45-50q-34-14-73-1t-60 46q-22 34-13 68.5t43 50.5 74.5 2.5 62.5-47.5zm94-121q8-13 3.5-26.5t-17.5-18.5q-14-5-28.5.5t-21.5 18.5q-17 31 13 45 14 5 29-.5t22-18.5zm174 107q-45 102-158 150t-224 12q-107-34-147.5-126.5t6.5-187.5q47-93 151.5-139t210.5-19q111 29 158.5 119.5t2.5 190.5zm312-160q-9-96-89-170t-208.5-109-274.5-21q-223 23-369.5 141.5t-132.5 264.5q9 96 89 170t208.5 109 274.5 21q223-23 369.5-141.5t132.5-264.5zm308 4q0 68-37 139.5t-109 137-168.5 117.5-226 83-270.5 31-275-33.5-240.5-93-171.5-151-65-199.5q0-115 69.5-245t197.5-258q169-169 341.5-236t246.5 7q65 64 20 209-4 14-1 20t10 7 14.5-.5 13.5-3.5l6-2q139-59 246-59t153 61q45 63 0 178-2 13-4.5 20t4.5 12.5 12 7.5 17 6q57 18 103 47t80 81.5 34 116.5zm-74-624q42 47 54.5 108.5t-6.5 117.5q-8 23-29.5 34t-44.5 4q-23-8-34-29.5t-4-44.5q20-63-24-111t-107-35q-24 5-45-8t-25-37q-5-24 8-44.5t37-25.5q60-13 119 5.5t101 65.5zm181-163q87 96 112.5 222.5t-13.5 241.5q-9 27-34 40t-52 4-40-34-5-52q28-82 10-172t-80-158q-62-69-148-95.5t-173-8.5q-28 6-52-9.5t-30-43.5 9.5-51.5 43.5-29.5q123-26 244 11.5t208 134.5z"/>
    </svg>',
    'renren' => '<svg class="nsafb-svg-icon" width="30" height="30" viewBox="0 0 1792 1792" xmlns="http://www.w3.org/2000/svg">
      <path d="M1261 1570q-171 94-368 94-196 0-367-94 138-87 235.5-211t131.5-268q35 144 132.5 268t235.5 211zm-495-1428v485q0 252-126.5 459.5t-330.5 306.5q-181-215-181-495 0-187 83.5-349.5t229.5-269.5 325-137zm898 756q0 280-181 495-204-99-330.5-306.5t-126.5-459.5v-485q179 30 325 137t229.5 269.5 83.5 349.5z"/>
    </svg>',
    'spotify' => '<svg class="nsafb-svg-icon" width="30" height="30" viewBox="0 0 1792 1792" xmlns="http://www.w3.org/2000/svg">
      <path d="M1255 1210q0-32-30-51-193-115-447-115-133 0-287 34-42 9-42 52 0 20 13.5 34.5t35.5 14.5q5 0 37-8 132-27 243-27 226 0 397 103 19 11 33 11 19 0 33-13.5t14-34.5zm96-215q0-40-35-61-237-141-548-141-153 0-303 42-48 13-48 64 0 25 17.5 42.5t42.5 17.5q7 0 37-8 122-33 251-33 279 0 488 124 24 13 38 13 25 0 42.5-17.5t17.5-42.5zm108-248q0-47-40-70-126-73-293-110.5t-343-37.5q-204 0-364 47-23 7-38.5 25.5t-15.5 48.5q0 31 20.5 52t51.5 21q11 0 40-8 133-37 307-37 159 0 309.5 34t253.5 95q21 12 40 12 29 0 50.5-20.5t21.5-51.5zm205 149q0 209-103 385.5t-279.5 279.5-385.5 103-385.5-103-279.5-279.5-103-385.5 103-385.5 279.5-279.5 385.5-103 385.5 103 279.5 279.5 103 385.5z"/>
    </svg>',
    'email' => '<svg class="nsafb-svg-icon" width="30" height="30" viewBox="0 0 1792 1792" xmlns="http://www.w3.org/2000/svg">
      <path d="M1664 1504v-768q-32 36-69 66-268 206-426 338-51 43-83 67t-86.5 48.5-102.5 24.5h-2q-48 0-102.5-24.5t-86.5-48.5-83-67q-158-132-426-338-37-30-69-66v768q0 13 9.5 22.5t22.5 9.5h1472q13 0 22.5-9.5t9.5-22.5zm0-1051v-24.5l-.5-13-3-12.5-5.5-9-9-7.5-14-2.5h-1472q-13 0-22.5 9.5t-9.5 22.5q0 168 147 284 193 152 401 317 6 5 35 29.5t46 37.5 44.5 31.5 50.5 27.5 43 9h2q20 0 43-9t50.5-27.5 44.5-31.5 46-37.5 35-29.5q208-165 401-317 54-43 100.5-115.5t46.5-131.5zm128-37v1088q0 66-47 113t-113 47h-1472q-66 0-113-47t-47-113v-1088q0-66 47-113t113-47h1472q66 0 113 47t47 113z"/>
    </svg>',
    'secondary_email' => '<svg class="nsafb-svg-icon" width="30" height="30" viewBox="0 0 1792 1792" xmlns="http://www.w3.org/2000/svg">
      <path d="M1664 1504v-768q-32 36-69 66-268 206-426 338-51 43-83 67t-86.5 48.5-102.5 24.5h-2q-48 0-102.5-24.5t-86.5-48.5-83-67q-158-132-426-338-37-30-69-66v768q0 13 9.5 22.5t22.5 9.5h1472q13 0 22.5-9.5t9.5-22.5zm0-1051v-24.5l-.5-13-3-12.5-5.5-9-9-7.5-14-2.5h-1472q-13 0-22.5 9.5t-9.5 22.5q0 168 147 284 193 152 401 317 6 5 35 29.5t46 37.5 44.5 31.5 50.5 27.5 43 9h2q20 0 43-9t50.5-27.5 44.5-31.5 46-37.5 35-29.5q208-165 401-317 54-43 100.5-115.5t46.5-131.5zm128-37v1088q0 66-47 113t-113 47h-1472q-66 0-113-47t-47-113v-1088q0-66 47-113t113-47h1472q66 0 113 47t47 113z"/>
    </svg>',
    'website' => '<svg class="nsafb-svg-icon" width="30" height="30" viewBox="0 0 1792 1792" xmlns="http://www.w3.org/2000/svg">
      <path d="M1408 928v320q0 119-84.5 203.5t-203.5 84.5h-832q-119 0-203.5-84.5t-84.5-203.5v-832q0-119 84.5-203.5t203.5-84.5h704q14 0 23 9t9 23v64q0 14-9 23t-23 9h-704q-66 0-113 47t-47 113v832q0 66 47 113t113 47h832q66 0 113-47t47-113v-320q0-14 9-23t23-9h64q14 0 23 9t9 23zm384-864v512q0 26-19 45t-45 19-45-19l-176-176-652 652q-10 10-23 10t-23-10l-114-114q-10-10-10-23t10-23l652-652-176-176q-19-19-19-45t19-45 45-19h512q26 0 45 19t19 45z"/>
    </svg>'
  );

  if( array_key_exists( $svg_name, $svgs ) )
    return $svgs[$svg_name];

  return;
}
/**
 * Output and Get SVG icon.
 * @since Nord Share and Follow Buttons 1.0
 */
function nsafb_get_svg( $svg_name ) {
  // Make sure that only our allowed tags and attributes are included.
  $svg = wp_kses(
    nsafb_get_svg_html( $svg_name ),
    array(
      'svg'     => array(
        'class'       => true,
        'xmlns'       => true,
        'width'       => true,
        'height'      => true,
        'viewbox'     => true
      ),
      'path'    => array(
        'd' => true,
      )
    )
  );

  if ( ! $svg ) {
    return false;
  }

  return $svg;
}
?>